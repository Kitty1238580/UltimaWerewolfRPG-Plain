package com.yourname.ultimatewerewolf;

import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(UltimateWerewolfMod.MODID)
public class UltimateWerewolfMod {
    public static final String MODID = "ultimatewerewolf";

    public UltimateWerewolfMod() {
        IEventBus eventBus = FMLJavaModLoadingContext.get().getModEventBus();
        eventBus.addListener(this::commonSetup);
        eventBus.addListener(this::clientSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        // Setup logic
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        // Client-side setup logic
    }
}
